#!/usr/bin/env python3
# d4215ecb-c593-11e8-a4be-00505601122b
# c751264b-78ee-11eb-a1a9-005056ad4f31
# bee39584-17d2-11e8-9de3-00505601122b
import argparse
import datetime
import os
import re
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2") # Report only TF errors by default

import numpy as np
import tensorflow as tf

from electra_czech_small_lc import ElectraCzechSmallLc
from reading_comprehension_dataset import ReadingComprehensionDataset

# TODO: Define reasonable defaults and optionally more parameters
parser = argparse.ArgumentParser()
parser.add_argument("--batch_size", default=8, type=int, help="Batch size.")
parser.add_argument("--epochs", default=15, type=int, nargs="*", help="Number of epochs.")
parser.add_argument("--initial_epoch", default=0, type=int, help="Start with this epoch (load progress from file).")
parser.add_argument("--seed", default=42, type=int, help="Random seed.")
parser.add_argument("--threads", default=None, type=int, help="Maximum number of threads to use.")
#parser.add_argument("--decay", default='cosine', type=str, nargs="*", help="Learning decay rate type")
parser.add_argument("--learning_rate", default=0.00005, type=float, nargs="*", help="Initial learning rate.")
#parser.add_argument("--learning_rate_final", default=0.0001, type=float, nargs="*", help="Final learning rate.")
#parser.add_argument("--label_smoothing", default=0.1, type=float, help="Label smoothing.")
parser.add_argument("--max_items", default=None, type=int, help="Only some first items are used, all if None is selected.")


maxLength = 512

def main(args):
    # Fix random seeds and threads
    np.random.seed(args.seed)
    tf.random.set_seed(args.seed)
    #tf.config.threading.set_inter_op_parallelism_threads(args.threads)
    #tf.config.threading.set_intra_op_parallelism_threads(args.threads)

    # Create logdir name
    args.logdir = os.path.join("logs", "{}-{}-{}".format(
        os.path.basename(globals().get("__file__", "notebook")),
        datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S"),
        ",".join(("{}={}".format(re.sub("(.)[^_]*_?", r"\1", key), value) for key, value in sorted(vars(args).items())))
    ))

    # Load the Electra Czech small lowercased
    electra = ElectraCzechSmallLc()

    # Load the data.
    dataset = ReadingComprehensionDataset()

    electraModel = electra.create_model(output_hidden_states=True)
    #electraModel.trainable = False
    tokenizer = electra.create_tokenizer()

    trainInput, trainOutput = GetData(tokenizer, dataset.train, max_items=args.max_items)
    devInput, devOutput = GetData(tokenizer, dataset.dev, max_items=args.max_items)
    testInput, _ = GetData(tokenizer, dataset.test, max_items=args.max_items, only_questions=True)

    # TODO: Create the model and train it
    input_ids = tf.keras.layers.Input(shape=[maxLength], dtype=tf.int32)
    token_type_ids = tf.keras.layers.Input(shape=[maxLength], dtype=tf.int32)
    attention_mask = tf.keras.layers.Input(shape=[maxLength], dtype=tf.int32)

    electraResult = electraModel(input_ids=input_ids, token_type_ids=token_type_ids, attention_mask=attention_mask)

    x = electraResult.last_hidden_state
    x = tf.keras.layers.Flatten()(x)
    x = tf.keras.layers.Dense(maxLength)(x)
    x = tf.keras.layers.Activation(tf.nn.softmax)(x)

    y = electraResult.last_hidden_state
    y = tf.keras.layers.Flatten()(y)
    y = tf.keras.layers.Dense(maxLength)(y)
    y = tf.keras.layers.Activation(tf.nn.softmax)(y)

    model = tf.keras.models.Model(inputs=[input_ids, token_type_ids, attention_mask], outputs=[x, y])

    #tb_callback = tf.keras.callbacks.TensorBoard(args.logdir, update_freq=100, profile_batch=0)
    #tb_callback._close_writers = lambda: None # A hack allowing to keep the writers open.

    callbacks = []
    #callbacks.append(tb_callback)
    #callbacks.append(ProgressSaver(model, test, morpho, args.logdir))
    callbacks.append(tf.keras.callbacks.ModelCheckpoint('checkpoints/reading_comprehension-{epoch:03d}.ckpt', save_weights_only=True, verbose=1))

    model.compile(
        #optimizer=tf.keras.optimizers.Adam(learning_rate=GetLearningRate(trainLength, 0)),
        optimizer=tf.keras.optimizers.Adam(learning_rate=args.learning_rate),
        loss=tf.keras.losses.SparseCategoricalCrossentropy(),
        metrics=tf.metrics.SparseCategoricalAccuracy(name="accuracy")
    )

    initialEpoch = args.initial_epoch
    if initialEpoch > 0:
        model.load_weights('checkpoints/reading_comprehension-%03d.ckpt' % initialEpoch)

    model.fit(
        trainInput, trainOutput,
        batch_size=args.batch_size,
        epochs=args.epochs,
        initial_epoch=initialEpoch,
        validation_data=(devInput, devOutput),
        callbacks=callbacks
    )

    # Generate test set annotations, but in args.logdir to allow parallel execution.
    os.makedirs(args.logdir, exist_ok=True)
    with open(os.path.join(args.logdir, "reading_comprehension.txt"), "w", encoding="utf-8") as predictions_file:
        # TODO: Predict the answers as strings (if the answer is not
        # in the context, use an empty string).
        predictedNumbers = model.predict(testInput)
        predictions = []

        encodedContexts = testInput[0]
        for i in range(len(encodedContexts)):
            start = np.argmax(predictedNumbers[0][i])
            end = np.argmax(predictedNumbers[1][i])

            #predictions.append(str(start) + ' : ' + str(end))
            predictions.append(tokenizer.decode(encodedContexts[i][start:end]))

        for answer in predictions:
            print(answer, file=predictions_file)

################################ Data ################################

# Input data is an array of objects of type:
#   {
#       context:
#       qas: [
#           {
#               question:
#               answers: [
#                   {
#                       text:
#                       start: // Starting index in context (by chars, not by tokens)
#                   }
#               ]
#           }
#       ]
#   }

def GetData(tokenizer, data, max_items=None, only_questions=False):
    input_ids = []
    token_type_ids = []
    attention_mask = []
    answerStarts = []
    answerEnds = []

    index = 0
    paragraphs = data.paragraphs
    for paragraph in paragraphs:
        if max_items != None and index >= max_items:
            break

        for qas in paragraph['qas']:
            if max_items != None and index >= max_items:
                break

            context = paragraph['context']
            question = qas['question']
            answers = qas['answers']

            if len(answers) == 0 and not only_questions:
                continue

            questionEncoding = tokenizer(context, question, padding='max_length', truncation=True, max_length=maxLength)
            input_ids.append(questionEncoding['input_ids'])
            token_type_ids.append(questionEncoding['token_type_ids'])
            attention_mask.append(questionEncoding['attention_mask'])

            if only_questions:
                continue
            
            answers = qas['answers']
            start = answers[0]['start']
            end = start + len(answers[0]['text'])

            answerStarts.append(int(questionEncoding.char_to_token(start) or 1))
            # We need the character before end, because only "end" would most likely result to ' ' char which would result to None result
            answerEnds.append(int(questionEncoding.char_to_token(end - 1) or 1) + 1)

            index += 1

    return [
        tf.constant(input_ids),
        tf.constant(token_type_ids),
        tf.constant(attention_mask)
    ], [
        tf.constant(answerStarts),
        tf.constant(answerEnds)
    ]

################################ Learning rate ################################

def GetLearningRate(trainLength):
    decaySteps = args.epochs * trainLength / args.batch_size
    if args.decay == 'polynomial':
        learningRate = tf.optimizers.schedules.PolynomialDecay(args.learning_rate, decaySteps, args.learning_rate_final)
    elif args.decay == 'exponential':
        decayRate = args.learning_rate_final / args.learning_rate
        learningRate = tf.optimizers.schedules.ExponentialDecay(args.learning_rate, decaySteps, decayRate)
    elif args.decay == 'cosine':
        learningRate = tf.keras.experimental.CosineDecay(args.learning_rate, decaySteps)
    else:
        learningRate = args.learning_rate
    return learningRate

################################ Main ################################

if __name__ == "__main__":
    args = parser.parse_args([] if "__file__" not in globals() else None)
    main(args)
