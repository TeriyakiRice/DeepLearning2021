#!/usr/bin/env python3
# d4215ecb-c593-11e8-a4be-00505601122b
# c751264b-78ee-11eb-a1a9-005056ad4f31
# bee39584-17d2-11e8-9de3-00505601122b
import argparse
import datetime
import os
import re
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2") # Report only TF errors by default

import numpy as np
import tensorflow as tf
import tensorflow_addons as tfa

from morpho_dataset import MorphoDataset

# TODO: Define reasonable defaults and optionally more parameters
parser = argparse.ArgumentParser()
parser.add_argument("--batch_size", default=100, type=int, help="Batch size.")
parser.add_argument("--cle_dim", default=256, type=int, help="CLE embedding dimension.")
parser.add_argument("--rnn_dim", default=256, type=int, help="RNN cell dimension.")
parser.add_argument("--epochs", default=100, type=int, help="Number of epochs.")
parser.add_argument("--seed", default=42, type=int, help="Random seed.")
parser.add_argument("--threads", default=None, type=int, help="Maximum number of threads to use.")

def main(args):
    # Fix random seeds and threads
    np.random.seed(args.seed)
    tf.random.set_seed(args.seed)
    #tf.config.threading.set_inter_op_parallelism_threads(args.threads)
    #tf.config.threading.set_intra_op_parallelism_threads(args.threads)

    # Create logdir name
    args.logdir = os.path.join("logs", "{}-{}-{}".format(
        os.path.basename(globals().get("__file__", "notebook")),
        datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S"),
        ",".join(("{}={}".format(re.sub("(.)[^_]*_?", r"\1", key), value) for key, value in sorted(vars(args).items())))
    ))

    # Load the data. Using analyses is only optional.
    morpho = MorphoDataset("czech_pdt", add_bow_eow=True)

    # TODO: Create the model and train it
    model = Network(args, morpho.train)

    def create_dataset(name):
        dataset = getattr(morpho, name).dataset
        dataset = dataset.map(lambda forms, lemmas, tags: (forms, lemmas))
        dataset = dataset.shuffle(len(dataset), seed=args.seed) if name == "train" else dataset
        dataset = dataset.apply(tf.data.experimental.dense_to_ragged_batch(args.batch_size))
        return dataset
    train, dev, test = create_dataset("train"), create_dataset("dev"), create_dataset("test")

    callbacks = []
    callbacks.append(model.tb_callback)
    callbacks.append(ProgressSaver(model, test, morpho, args.logdir))

    model.fit(
        train,
        epochs=args.epochs,
        validation_data=dev,
        callbacks=callbacks
    )

    test_logs = model.evaluate(test, return_dict=True)
    model.tb_callback.on_epoch_end(args.epochs, {"val_test_" + metric: value for metric, value in test_logs.items()})

    # Generate test set annotations, but in args.logdir to allow parallel execution.
    os.makedirs(args.logdir, exist_ok=True)
    with open(os.path.join(args.logdir, "lemmatizer_competition.txt"), "w", encoding="utf-8") as predictions_file:
        # Predict the tags on the test set; update the following prediction
        # command if you use other output structre than in lemmatizer_noattn.
        predictions = model.predict(test)
        for sentence in predictions:
            for word in sentence:
                print(word.numpy().decode("utf-8"), file=predictions_file)
            print(file=predictions_file)

################################ Model Blocks ################################

class SourceRnn(tf.keras.Model):
    def __init__(self):
        super(SourceRnn, self).__init__()
        self._rnnLayers = []
        self._rnnLayers.append(RnnBlock(dimension=256))
        self._rnnLayers.append(RnnBlock(dimension=256, dropout=0.5, recurent=True))
        self._rnnLayers.append(RnnBlock(dimension=256, recurent=True))
        self._rnnLayers.append(RnnBlock(dimension=256, dropout=0.5, recurent=True))
        self._rnnLayers.append(RnnBlock(dimension=256, recurent=True))
        self._rnnLayers.append(RnnBlock(dimension=256, dropout=0.5, recurent=True))

        self._outputLayer = tf.keras.layers.Bidirectional(tf.keras.layers.GRU(256), merge_mode='sum')

    def call(self, input_tensor, training=False):
        x = input_tensor

        for rnnLayer in self._rnnLayers:
            x = rnnLayer(x)

        x = self._outputLayer(x)

        return x

class RnnBlock(tf.keras.Model):
    def __init__(self, dimension=128, dropout=0, recurent=False):
        super(RnnBlock, self).__init__()
        self._mainLayer = tf.keras.layers.Bidirectional(tf.keras.layers.GRU(dimension, return_sequences=True), merge_mode='sum')

        self._dropout = dropout
        if dropout > 0:
            self._dropoutLayer = tf.keras.layers.Dropout(dropout)
        
        self._recurent = recurent
        if recurent:
            self._recurentConnection = tf.keras.layers.Add()

    def call(self, input_tensor, training=False):
        x = input_tensor
        x = self._mainLayer(x)

        if self._dropout > 0:
            x = self._dropoutLayer(x)

        if self._recurent:
            x = self._recurentConnection([input_tensor, x])

        return x

################################ Progress Saver ################################

class ProgressSaver(tf.keras.callbacks.Callback):
    def __init__(self, model, dataset, morpho, logdir):
        self._model = model
        self._dataset = dataset
        self._morpho = morpho
        self._logdir = logdir
        super().__init__()

    def on_epoch_end(self, epoch, logs=None):
        predictions = self._model.predict(self._dataset)
        filename = os.path.join(self._logdir, 'test' + '-e' + "{:0>3d}".format(epoch + 1))

        """
        Too big (~ 1GB)
        with open(filename + '.npy', 'wb') as binary_file:
            np.save(binary_file, predictions)
        """
        with open(filename + '.txt', 'w', encoding='utf-8') as text_file:
            for sentence in predictions:
                for word in sentence:
                    print(word.numpy().decode("utf-8"), file=text_file)
                print(file=text_file)

################################ Model ################################

class Network(tf.keras.Model):
    def __init__(self, args, train):
        super().__init__()

        self.source_mapping = train.forms.char_mapping
        self.target_mapping = train.lemmas.char_mapping
        self.target_mapping_inverse = type(self.target_mapping)(
            mask_token=None, vocabulary=self.target_mapping.get_vocabulary(), invert=True)

        # TODO: Define
        # - `self.source_embedding` as an embedding layer of source chars into `args.cle_dim` dimensions
        # - `self.source_rnn` as a bidirectional GRU with `args.rnn_dim` units, returning only the last output,
        #   summing opposite directions
        ## this is decoder
        self.source_embedding = tf.keras.layers.Embedding(self.source_mapping.vocab_size(), args.cle_dim)
        self.source_rnn = SourceRnn()

        # TODO: Then define
        # - `self.target_embedding` as an embedding layer of target chars into `args.cle_dim` dimensions
        # - `self.target_rnn_cell` as a GRUCell with `args.rnn_dim` units
        # - `self.target_output_layer` as a Dense layer into as many outputs as there are unique target chars
        self.target_embedding = tf.keras.layers.Embedding(self.target_mapping.vocab_size(), args.cle_dim)
        self.target_rnn_cell = tf.keras.layers.GRUCell(args.rnn_dim)
        self.target_output_layer = tf.keras.layers.Dense(self.target_mapping.vocab_size())

        # Compile the model
        self.compile(
            optimizer=tf.optimizers.Adam(),
            loss=tf.losses.SparseCategoricalCrossentropy(from_logits=True),
            metrics=[tf.metrics.Accuracy(name="accuracy")],
        )

        self.tb_callback = tf.keras.callbacks.TensorBoard(args.logdir, update_freq=100, profile_batch=0)
        self.tb_callback._close_writers = lambda: None # A hack allowing to keep the writers open.

    class DecoderTraining(tfa.seq2seq.BaseDecoder):
        def __init__(self, lemmatizer, *args, **kwargs):
            self.lemmatizer = lemmatizer
            super().__init__.__wrapped__(self, *args, **kwargs)

        @property
        def batch_size(self):
            # TODO: Return the batch size of self.source_states, using tf.shape
            return tf.shape(self.source_states)[0]
        @property
        def output_size(self):
            # TODO: Return `tf.TensorShape(number of logits per each output element)`
            # By output element we mean characters.
            return tf.TensorShape(self.lemmatizer.target_output_layer.units)
        @property
        def output_dtype(self):
            # TODO: Return the type of the logits
            return self.lemmatizer.target_output_layer.dtype

        def initialize(self, layer_inputs, initial_state=None):
            self.source_states, self.targets = layer_inputs

            # TODO: Define `finished` as a vector of self.batch_size of `False` [see tf.fill].
            finished = tf.fill([self.batch_size], False)

            # TODO: Define `inputs` as a vector of self.batch_size of MorphoDataset.Factor.BOW,
            # embedded using self.lemmatizer.target_embedding
            inputs = self.lemmatizer.target_embedding(tf.fill([self.batch_size], MorphoDataset.Factor.BOW))

            # TODO: Define `states` as self.source_states
            states = self.source_states

            return finished, inputs, states

        def step(self, time, inputs, states, training):
            # TODO: Pass `inputs` and `[states]` through self.lemmatizer.target_rnn_cell,
            # which returns `(outputs, [states])`.
            outputs, [states] = self.lemmatizer.target_rnn_cell(inputs, [states])

            # TODO: Overwrite `outputs` by passing them through self.lemmatizer.target_output_layer,
            outputs = self.lemmatizer.target_output_layer(outputs)

            # TODO: Define `next_inputs` by embedding `time`-th chars from `self.targets`.
            #next_inputs = self.lemmatizer.target_embedding(tf.gather(self.targets, time, axis=-1))
            next_inputs = self.lemmatizer.target_embedding(self.targets[:, time])

            # TODO: Define `finished` as True if `time`-th char from `self.targets` is
            # `MorphoDataset.Factor.EOW`, False otherwise.
            finished = self.targets[:, time] == MorphoDataset.Factor.EOW

            return outputs, states, next_inputs, finished

    class DecoderPrediction(DecoderTraining):
        @property
        def output_size(self):
            # TODO: Return `tf.TensorShape()` describing a scalar element,
            # because we are generating scalar predictions now.
            return tf.TensorShape([])
        @property
        def output_dtype(self):
            # TODO: Return the type of the generated predictions
            return tf.int32

        def initialize(self, layer_inputs, initial_state=None):
            # Use `initialize` from the DecoderTraining, passing None as targets
            return super().initialize([layer_inputs, None], initial_state)

        def step(self, time, inputs, states, training):
            # TODO(DecoderTraining): Pass `inputs` and `[states]` through self.lemmatizer.target_rnn_cell,
            # which returns `(outputs, [states])`.
            (outputs, [states]) = self.lemmatizer.target_rnn_cell(inputs, [states])

            # TODO(DecoderTraining): Overwrite `outputs` by passing them through self.lemmatizer.target_output_layer,
            outputs = self.lemmatizer.target_output_layer(outputs)

            # TODO: Overwrite `outputs` by passing them through `tf.argmax` on suitable axis and with
            # `output_type=tf.int32` parameter.
            outputs = tf.argmax(outputs, axis=-1, output_type=tf.int32)

            # TODO: Define `next_inputs` by embedding the `outputs`
            next_inputs = self.lemmatizer.target_embedding(outputs)

            # TODO: Define `finished` as True if `outputs are `MorphoDataset.Factor.EOW`, False otherwise.
            finished = outputs == MorphoDataset.Factor.EOW

            return outputs, states, next_inputs, finished

    # If `targets` is given, we are in the teacher forcing mode.
    # Otherwise, we run in autoregressive mode.
    def call(self, inputs, targets=None):
        # FIX: Get indices of valid lemmas and reshape the `source_charseqs`
        # so that it is a list of valid sequences, instead of a
        # matrix of sequences, some of them padding ones.
        source_charseqs = inputs.values
        source_charseqs = tf.strings.unicode_split(source_charseqs, "UTF-8")
        source_charseqs = self.source_mapping(source_charseqs)
        if targets is not None:
            target_charseqs = targets.values
            target_charseqs = target_charseqs.to_tensor()

        # TODO: Embed source_charseqs using `source_embedding`
        source_charseqs = self.source_embedding(source_charseqs)

        # TODO: Run source_rnn on the embedded sequences, returning outputs in `source_states`.
        source_states = self.source_rnn(source_charseqs)

        # Run the appropriate decoder
        if targets is not None:
            # TODO: Create a self.DecoderTraining by passing `self` to its constructor.
            # Then run it on `[source_states, target_charseqs]` input,
            # storing the first result in `output` and the third result in `output_lens`.
            output, _, output_lens = self.DecoderTraining(self)([source_states, target_charseqs])
        else:
            # TODO: Create a self.DecoderPrediction by using:
            # - `self` as first argument to its constructor
            # - `maximum_iterations=tf.cast(source_charseqs.bounding_shape(1) + 10, tf.int32)`
            #   as another argument, which indicates that the longest prediction
            #   must be at most 10 characters longer than the longest input.
            #
            # Then run it on `source_states`, storing the first result in `output`
            # and the third result in `output_lens`. Finally, because we do not want
            # to return the `[EOW]` symbols, decrease `output_lens` by one.
            output, _, output_lens = self.DecoderPrediction(self, maximum_iterations=tf.cast(source_charseqs.bounding_shape(1) + 10, tf.int32))(source_states)
            output_lens -= 1

        # Reshape the output to the original matrix of lemmas
        # and explicitly set mask for loss and metric computation.
        output = tf.RaggedTensor.from_tensor(output, output_lens)
        output = inputs.with_values(output)
        return output

    def train_step(self, data):
        x, y = data

        # Convert `y` by splitting characters, mapping characters to ids using
        # `self.target_mapping` and finally appending `MorphoDataset.Factor.EOW`
        # to every sequence.
        y_targets = self.target_mapping(tf.strings.unicode_split(y.values, "UTF-8"))
        y_targets = tf.concat(
            [y_targets, tf.fill([y_targets.bounding_shape(0), 1], tf.constant(MorphoDataset.Factor.EOW, tf.int64))], axis=-1)
        y_targets = y.with_values(y_targets)

        with tf.GradientTape() as tape:
            y_pred = self(x, targets=y_targets, training=True)
            loss = self.compiled_loss(y_targets.flat_values, y_pred.flat_values, regularization_losses=self.losses)
        self.optimizer.minimize(loss, self.trainable_variables, tape=tape)
        return {"loss": loss}

    def predict_step(self, data):
        if isinstance(data, tuple): data = data[0]
        y_pred = self(data, training=False)
        y_pred = self.target_mapping_inverse(y_pred)
        y_pred = tf.strings.reduce_join(y_pred, axis=-1)
        return y_pred

    def test_step(self, data):
        x, y = data
        y_pred = self.predict_step(data)
        self.compiled_metrics.update_state(tf.ones_like(y.values, dtype=tf.int32), tf.cast(y_pred.values == y.values, tf.int32))
        return {m.name: m.result() for m in self.metrics}

################################ Main ################################

if __name__ == "__main__":
    args = parser.parse_args([] if "__file__" not in globals() else None)
    main(args)
