#!/usr/bin/env python3
# d4215ecb-c593-11e8-a4be-00505601122b
# c751264b-78ee-11eb-a1a9-005056ad4f31
# bee39584-17d2-11e8-9de3-00505601122b
import argparse
import datetime
from gc import callbacks
import os
import re
from turtle import width
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2") # Report only TF errors by default

import numpy as np
import tensorflow as tf
import transformers # transformers >= 4 is required

from electra_czech_small_lc import ElectraCzechSmallLc
from text_classification_dataset import TextClassificationDataset

# TODO: Define reasonable defaults and optionally more parameters
parser = argparse.ArgumentParser()
parser.add_argument("--batch_size", default=100, type=int, help="Batch size.")
parser.add_argument("--epochs", default=[1, 20], type=int, nargs="*", help="Number of epochs.")
parser.add_argument("--seed", default=42, type=int, help="Random seed.")
parser.add_argument("--threads", default=None, type=int, help="Maximum number of threads to use.")
parser.add_argument("--decay", default=['cosine', 'cosine'], type=str, nargs="*", help="Learning decay rate type")
parser.add_argument("--learning_rate", default=[0.001, 0.0001], type=float, nargs="*", help="Initial learning rate.")
parser.add_argument("--learning_rate_final", default=[0.0001, 0.00001], type=float, nargs="*", help="Final learning rate.")
parser.add_argument("--label_smoothing", default=0.1, type=float, help="Label smoothing.")

def main(args):
    # Fix random seeds and threads
    np.random.seed(args.seed)
    tf.random.set_seed(args.seed)
    #tf.config.threading.set_inter_op_parallelism_threads(args.threads)
    #tf.config.threading.set_intra_op_parallelism_threads(args.threads)

    # Create logdir name
    args.logdir = os.path.join("logs", "{}-{}-{}".format(
        os.path.basename(globals().get("__file__", "notebook")),
        datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S"),
        ",".join(("{}={}".format(re.sub("(.)[^_]*_?", r"\1", key), value) for key, value in sorted(vars(args).items())))
    ))

    # Load the Electra Czech small lowercased
    electra = ElectraCzechSmallLc()

    # TODO: Load the data. Consider providing a `tokenizer` to the
    # constructor of the TextClassificationDataset.
    tokenizer = electra.create_tokenizer()
    facebook = TextClassificationDataset("czech_facebook", tokenizer)

    maxLength = GetMaxLength(facebook)
    trainInput, trainOutput = GetInputOutput(facebook, 'train')
    devInput, devOutput = GetInputOutput(facebook, 'dev')
    testInput, _ = GetInputOutput(facebook, 'test')

    # TODO: Create the model and train it
    electraModel = electra.create_model()
    electraModel.trainable = False
    
    input = tf.keras.layers.Input(shape=[maxLength], dtype=tf.int32)
    mask = tf.keras.layers.Input(shape=[maxLength], dtype=tf.int32)

    electraResult = electraModel(input_ids=input, attention_mask=mask)

    x = electraResult.last_hidden_state
    x = tf.keras.layers.Flatten()(x)
    x = tf.keras.layers.Dense(1024, activation=tf.nn.relu)(x)
    x = tf.keras.layers.Dense(3, activation=tf.nn.softmax)(x)

    model = tf.keras.models.Model(inputs=[input, mask], outputs=x)

    #tb_callback = tf.keras.callbacks.TensorBoard(args.logdir, update_freq=100, profile_batch=0)
    #tb_callback._close_writers = lambda: None # A hack allowing to keep the writers open.

    callbacks = []
    #callbacks.append(tb_callback)
    #callbacks.append(ProgressSaver(model, test, morpho, args.logdir))

    trainLength = trainOutput.shape[0]
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=GetLearningRate(trainLength, 0)),
        loss=tf.keras.losses.CategoricalCrossentropy(label_smoothing=args.label_smoothing),
        metrics=tf.metrics.CategoricalAccuracy(name="accuracy")
    )

    model.fit(
        trainInput, trainOutput,
        batch_size=args.batch_size,
        epochs=args.epochs[0],
        validation_data=(devInput, devOutput),
        callbacks=callbacks
    )

    model.trainable = True

    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=GetLearningRate(trainLength, 1)),
        loss=tf.keras.losses.CategoricalCrossentropy(label_smoothing=args.label_smoothing),
        metrics=tf.metrics.CategoricalAccuracy(name="accuracy")
    )

    model.fit(
        trainInput, trainOutput,
        batch_size=args.batch_size,
        epochs=args.epochs[0] + args.epochs[1],
        validation_data=(devInput, devOutput),
        callbacks=callbacks,
        initial_epoch = args.epochs[0]
    )

    #test_logs = model.evaluate(testInput, return_dict=True)
    #tb_callback.on_epoch_end(args.epochs, {"val_test_" + metric: value for metric, value in test_logs.items()})

    # Generate test set annotations, but in args.logdir to allow parallel execution.
    os.makedirs(args.logdir, exist_ok=True)
    with open(os.path.join(args.logdir, "sentiment_analysis.txt"), "w", encoding="utf-8") as predictions_file:
        # TODO: Predict the tags on the test set.
        predictions = model(testInput)

        label_strings = facebook.test.label_mapping.get_vocabulary()
        for sentence in predictions:
            print(label_strings[np.argmax(sentence)], file=predictions_file)

################################ Data ################################

def GetMaxLength(facebook):
    return max([GetMaxDataLength(facebook, name) for name in ['train', 'dev', 'test']])

def GetMaxDataLength(facebook, name):
    return max([len(data['input_ids']) for data in getattr(facebook, name).data['tokens']])

def GetInputOutput(facebook, name):
    return GetTokens(facebook, name), GetLabels(facebook, name)

def GetTokens(facebook, name):
    rawTokens = getattr(facebook, name).data['tokens']
    inputIds = [rawToken['input_ids'] for rawToken in rawTokens]
    inputIdsTensor = tf.ragged.constant(inputIds)

    length = len(inputIds)
    width = GetMaxLength(facebook)
    tokens = inputIdsTensor.to_tensor(shape=[length, width])
    mask = tf.sequence_mask(inputIdsTensor.row_lengths(), maxlen=width)
    return [tokens, mask]

def GetLabels(facebook, name):
    dataset = getattr(facebook, name)
    rawLabels = dataset.label_mapping(dataset.data['labels'])
    return tf.one_hot(rawLabels, dataset.label_mapping.vocabulary_size())

################################ Learning rate ################################

def GetLearningRate(trainLength, iteration):
    decaySteps = args.epochs[iteration] * trainLength / args.batch_size
    if args.decay[iteration] == 'polynomial':
        learningRate = tf.optimizers.schedules.PolynomialDecay(args.learning_rate[iteration], decaySteps, args.learning_rate_final[iteration])
    elif args.decay[iteration] == 'exponential':
        decayRate = args.learning_rate_final[iteration] / args.learning_rate[iteration]
        learningRate = tf.optimizers.schedules.ExponentialDecay(args.learning_rate[iteration], decaySteps, decayRate)
    elif args.decay[iteration] == 'cosine':
        learningRate = tf.keras.experimental.CosineDecay(args.learning_rate[iteration], decaySteps)
    else:
        learningRate = args.learning_rate[iteration]
    return learningRate

################################ Main ################################

if __name__ == "__main__":
    args = parser.parse_args([] if "__file__" not in globals() else None)
    main(args)
